/*

WINTERED TEMPLATE  V1.0 BY SUPVIEW.BE


00. PARALLAX SETTING
01. NAVBAR STICKY + SELECTED
02. SMOOTH SCROLLING OF NAV BAR
03. HEADER + H2 TEXT
04. INTERSECTION ( TESTIMONIAL )
05. WORKS SLIDER EXEMPLE
06. CLIENTS INTERSECTION SLIDER
07. PROCESS SLIDER
08. RESPONSIVE MENU
09. ANNIMATIONS MAKE IT APPEAR
10. LOADING PAGE

*/


var ajax_form = true;


$(document).ready(function () {


/*-----------------------------------------------------------------------------------*/
/*	00. PARALLAX SETTING
/*-----------------------------------------------------------------------------------*/

  
  mediaCheck({
    media: '(max-width: 768px)',
    entry: function() {
    
      // NONE FOR DISABLE PARALLAX SCROLLING IN SMARTHPHONES & TABLET
      
    },
    exit: function() {



  

			YUI().use('node', function (Y) {
			  Y.on('domready', function () {
			    
			    var scrolling = false,
			        lastScroll,
			        i = 0;
			    
			    Y.on('scroll', function () {
			      if (scrolling === false) {
			        fade();
			      }
			      scrolling = true;
			      setTimeout(function () {
			        scrolling = false;
			        fade();
			      }, 0);
			    });
			    
			    function fade() {
			      
			      lastScroll = window.scrollY;
			      
			      Y.one('#leadFader h1').setStyles({
			        'transform' : 'translate3d(0,' + Math.round(lastScroll/1.8) + 'px,0)',
			        'opacity' : (100 - lastScroll/7)/50
			      });
			      
			      
			      if (scrolling === true) {
			        window.requestAnimationFrame(fade);
			      }
			    }
			    
			  });
			});



var cbpAnimatedHeader = (function() {

	var docElem = document.documentElement,
		header = document.querySelector( '.cbp-af-header' ),
		didScroll = false,
		changeHeaderOn = 10;

	function init() {
		window.addEventListener( 'scroll', function( event ) {
			if( !didScroll ) {
				didScroll = true;
				setTimeout( scrollPage, 200 );
			}
		}, false );
	}

	function scrollPage() {
		var sy = scrollY();
		if ( sy >= changeHeaderOn ) {
			classie.add( header, 'cbp-af-header-shrink' );
		}
		else {
			classie.remove( header, 'cbp-af-header-shrink' );
		}
		didScroll = false;
	}

	function scrollY() {
		return window.pageYOffset || docElem.scrollTop;
	}

	init();

})();

	




    }
  });



    


/*-----------------------------------------------------------------------------------*/
/*	01. NAVBAR STICKY + SELECTED
/*-----------------------------------------------------------------------------------*/
	
// $(".ico-menu").sticky({topSpacing:0});
 $(".french").hide();


	

(function() {
  $(window).scroll(function() {
    var oVal;
    oVal = $(window).scrollTop() / 240;
    return $(".blur").css("opacity", oVal);
  });

}).call(this);




/*-----------------------------------------------------------------------------------*/
/*	02. SMOOTH SCROLLING OF NAV BAR
/*-----------------------------------------------------------------------------------*/
	

$('.goto').click(function(e){
    $('html,body').scrollTo(this.hash,this.hash);
    e.preventDefault();
});



/*-----------------------------------------------------------------------------------*/
/*	03. HEADER + H2 TEXT
/*-----------------------------------------------------------------------------------*/





var TxtRotate = function(el, toRotate, period) {
  this.toRotate = toRotate;
  this.el = el;
  this.loopNum = 0;
  this.period = parseInt(period, 100) || 1000;
  this.txt = '';
  this.tick();
  this.isDeleting = false;
};

TxtRotate.prototype.tick = function() {
  var i = this.loopNum % this.toRotate.length;
  var fullTxt = this.toRotate[i];

  if (this.isDeleting) {
    this.txt = fullTxt.substring(0, this.txt.length - 1);
  } else {
    this.txt = fullTxt.substring(0, this.txt.length + 1);
  }

  this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

  var that = this;
  var delta = 150 - Math.random() * 100;

  if (this.isDeleting) { delta /= 2; }

  if (!this.isDeleting && this.txt === fullTxt) {
    delta = this.period;
    this.isDeleting = true;
  } else if (this.isDeleting && this.txt === '') {
    this.isDeleting = false;
    this.loopNum++;
    delta = 500;
  }

  setTimeout(function() {
    that.tick();
  }, delta);
};

window.onload = function() {
  var elements = document.getElementsByClassName('txt-rotate');
  for (var i=0; i<elements.length; i++) {
    var toRotate = elements[i].getAttribute('data-rotate');
    var period = elements[i].getAttribute('data-period');
    if (toRotate) {
      new TxtRotate(elements[i], JSON.parse(toRotate), period);
    }
  }
  // INJECT CSS
  var css = document.createElement("style");
  css.type = "text/css";
  css.innerHTML = ".txt-rotate > .wrap { 10px; border-right: 0.08em solid #FFF }";
  document.body.appendChild(css);
};

$(function(){
  var onClass = "on";
  var showClass = "show";
  
  $("input").bind("checkval",function(){
    var label = $(this).prev("label");
    if(this.value !== ""){
      label.addClass(showClass);
    } else {
      label.removeClass(showClass);
    }
  }).on("keyup",function(){
    $(this).trigger("checkval");
  }).on("focus",function(){
    $(this).prev("label").addClass(onClass);
  }).on("blur",function(){
      $(this).prev("label").removeClass(onClass);
  }).trigger("checkval");
});






/*-----------------------------------------------------------------------------------*/
    /*	02. FLEXSLIDER - TESTIMONIAL
/*-----------------------------------------------------------------------------------*/


    $('#slider1').flexslider({
        animation: "fade",
        directionNav: false,
        controlNav: false,
        smoothHeight: false,
        animationLoop: true,
        slideshowSpeed: 5000,
        slideToStart: 0,
    });

    $('#slider2').flexslider({
        animation: "slide",
        directionNav: true,
        controlNav: false,
        smoothHeight: true,
        animationLoop: true,
        sync: "#slider1",
        slideshowSpeed: 5000,
        slideToStart: 0,
    });


/*-----------------------------------------------------------------------------------*/
    /*	06. FORM SENDER
/*-----------------------------------------------------------------------------------*/



    /* Form Submission */
    $('form').submit(function () {

        var form_data = $(this).serialize();

        if (validateEmail($('input[name=email]').attr('value'))) {

            if (typeof ajax_form !== "undefined" && ajax_form === true) {

                $.post($(this).attr('action'), form_data, function (data) {
                    $('form').show('slow', function () {
                        $(this).after('<div class="clear"></div> <p class="msg-ok">' + data + '</p>');
                    });
                    $('.spam').hide();
                    $('.msg-ok').delay(100).effect("pulsate", {
                        times: 1
                    }, 1000).hide();
                });

                return false;

            }

        } else {
            $('p.spam').text('Please enter a valid e-mail').effect("pulsate", {
                times: 3
            }, 1000);
            return false;
        }

    });


    /* Validate E-Mail */

    function validateEmail(email) {
        // http://stackoverflow.com/a/46181/11236

        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }




/*-----------------------------------------------------------------------------------*/
/*	08. BUTTON FULL SCREEN
/*-----------------------------------------------------------------------------------*/



$(".expandit").click(function() {
    $('.largeScreenshots').fadeIn('slow');
});

$(".closeit").click(function() {
    closeAction();
});

$(".picHolder").click(function() {
    closeAction();
});


$('#mailform').hide();
$(".to_mailform").click(function() {
    $('#mailform').slideToggle('slow');
    $('html, body').animate({
	scrollTop: $("#mailform").offset().top
}, 800);
});



/*-----------------------------------------------------------------------------------*/
/*	08. SI ESCAPE ON FERME LE SLIDE
/*-----------------------------------------------------------------------------------*/

function closeAction() {
	
	var $list;
	
	/* je passe dans TOUTES les div ayant la classe 'largeScreenshots' ET visible  */
	$list = $('.largeScreenshots:visible');
	for ( var i = 0; i < $list.length; i++ ) {
		el = $list.eq(i);
		el.fadeOut("slow");
		return;
	}
	/* aussi non, aucune 'largeScreenshots' n'est ouverte, donc, je passe dans TOUTES les 'slide_portfolio' ET visible */
	$list = $('.largeScreenshots');
	for ( var i = 0; i < $list.length; i++ ) {
		$list.eq(i).hide();
	}
	
	$list = $('.slide_portfolio:visible');
	for ( var i = 0; i < $list.length; i++ ) {
		el = $list.eq(i); 
		el.slideUp();
		return;
	}
		
}

$(window).keyup(function(e) {

	switch( e.keyCode ) {
		
		case 27:
			closeAction();
			$('#mailform').slideUp('slow');
			break;
			
		default:
			console.log( "keyup: " + e.keyCode );
		
	}


});




/*-----------------------------------------------------------------------------------*/
/*	09. ANNIMATIONS MAKE IT APPEAR
/*-----------------------------------------------------------------------------------*/



  $('.make-it-appear-top').waypoint(function(direction) {
      $(this).addClass('animated fadeInDown');
    }, {
      offset: '80%'
  });

  $('.make-it-appear-left').waypoint(function(direction) {
      $(this).addClass('animated fadeInLeft');
    }, {
      offset: '80%'
  });

  $('.make-it-appear-right').waypoint(function(direction) {
      $(this).addClass('animated fadeInRight');
    }, {
      offset: '80%'
  });

  $('.make-it-appear-bottom').waypoint(function(direction) {
      $(this).addClass('animated fadeInUp');
    }, {
      offset: '80%'
  });

  $('.bounce').waypoint(function(direction) {
      $(this).addClass('animated bounce');
    }, {
      offset: '70%'
  });

  $('.pulse').waypoint(function(direction) {
      $(this).addClass('animated pulse');
    }, {
      offset: '50%'
  });



});



/*-----------------------------------------------------------------------------------*/
/*	10. LOADING PAGE
/*-----------------------------------------------------------------------------------*/



$(window).load(function() {
        // will first fade out the loading animation
    jQuery("#loading-animation").fadeOut();
	        // will fade out the whole DIV that covers the website.
    jQuery("#preloader").delay(600).fadeOut("slow");
  
    
});




